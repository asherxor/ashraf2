<?php

return [
    'name' => 'Accounting',
    'module_version' => '10.0',
    'pid' => 16,
];
