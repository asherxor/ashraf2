<table style="width:100%;">
    <thead>
    <tr>
        <td>

            <?php $logo = asset( 'uploads/invoice_logos/' . $invoice_layout->logo); ?>
            @if(!empty($logo) &&  $invoice_layout->show_logo)
                <div class="text-center">
                 <img src="{{$logo}}" style="height: 150px" class="img">
                </div>
            @endif

            <p class="text-left">
                @if(!empty($business_location->name))
                    <br>
                    {{__('lang_v1.location_ins1')}}: {{$business_location->name}}
                @endif
                @if(!empty($business_location->city) || !empty($business_location->state) || !empty($business_location->country))
                    <br>
                    {{implode(',', array_filter([$business_location->city, $business_location->state, $business_location->country]))}}
                @endif
                @if(!empty($business_location->city) || !empty($business_location->state) || !empty($business_location->country))
                    <br>
                        {{__('contact.mobile')}}: {{ $business_location->mobile }}
                @endif
                @if(!empty($business_location->custom_field1) || !empty($business_location->custom_field2))
                        <br>
                    @lang('accounting::lang.commercial_registration_no'):
                    {{ $business_location->custom_field1 }}
                     -
                    @lang('contact.tax_no'):
                    {{ $business_location->custom_field2 }}
                @endif
            </p>
                <hr/>
        </td>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>
            <div class="text-center">
                @lang('accounting::lang.add_receipt')
                <br/>
                ( @lang('lang_v1.cn_no_label'): {{$journal->ref_no}} )
            </div>
            <p class="text-left">
                @lang('accounting::lang.receive_from')
                <br>
                {{$debit->account()->first()->name}}
            </p>
            <p class="text-left">
                @lang('purchase.amount'):
                <?php
                $all_amount = 0;
                ?>
                @foreach($journal->childs() as $child)
                    @if($child->type == "debit")
                        <?php $all_amount += $child->amount; ?>
                    @endif
                @endforeach
                @format_currency($all_amount)

                &nbsp;&nbsp;&nbsp;

                @lang('lang_v1.payment_method'):

                <?php
                 $parent_credit = $credit->account()->first()->parent()->first();
                ?>
                @if(isset($parent_credit->id))

                    @if($parent_credit->gl_code == 1101)
                        @lang('lang_v1.cash')
                    @elseif($parent_credit->gl_code == 1102)
                        @lang('accounting::lang.from_bank')
                    @else
                        {{$credit->account()->first()->name}}
                    @endif
                @else
                    {{$credit->account()->first()->name}}
                @endif


                <br>
                @lang('purchase.payment_note'):
                {{$journal->note}}
            </p>
            <hr/>
        </td>
    </tr>
    </tbody>
    <tfoot>
    <tr>
        <th>

            <div class="text-left">

                @lang('lang_v1.cn_no_label'): {{$journal->ref_no}}

                &nbsp;&nbsp;&nbsp;

                @lang('lang_v1.total_paying'): {{ @format_datetime($journal->operation_date)  }}

            </div>
            <br><br>
            <div class="text-center">

                @lang('accounting::lang.accounter')

                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                @lang('accounting::lang.the_recipient')

            </div>

        </th>
    </tr>
    </tfoot>
</table>