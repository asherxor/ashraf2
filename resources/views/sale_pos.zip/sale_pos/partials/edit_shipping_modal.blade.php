<!-- Edit Shipping Modal -->
<div class="modal fade" tabindex="-1" role="dialog" id="posShippingModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">@lang('sale.shipping')</h4>
				<div class="row">
					<?php
					$is_show = 1;
					?>
					@if(
                    request()->segment(3) == 'edit' &&
                    __('khairataladel::lang.khairataladel') != 'khairataladel::lang.khairataladel' &&
                    !empty($transaction->shipping_details) &&
                    json_decode($transaction->shipping_details,true) != null &&
                    is_array(json_decode($transaction->shipping_details,true))
                    )
						<?php
						$is_show = 2;
						?>
					@endif
					<div class="col-md-12 mt-15">
						<label class="radio-inline" style="margin: 10px;">
							<input type="radio" name="shipments_now" id="aaaa1" value="1" {{$is_show == 1 ? 'checked' : '' }}>
							@lang('barcode.default')
						</label>
						<br>
						@if(__('khairataladel::lang.khairataladel') != 'khairataladel::lang.khairataladel')
						<label class="radio-inline" style="margin: 10px;">
							<input type="radio" name="shipments_now" id="aaaa2" value="2"  {{$is_show == 2 ? 'checked' : '' }}>
							@lang('khairataladel::lang.khairataladel')
						</label>
						@endif
					</div>
				</div>
			</div>
			<div class="modal-body">
				<div id="aaa1" style="display: {{$is_show == 1 ? 'block' : 'none' }}" class="row">
					<div class="col-md-6">
						<div class="form-group">
							{!! Form::label('shipping_details_modal', __('sale.shipping_details') . ':*' ) !!}
							{!! Form::textarea('shipping_details_modal', !empty($transaction->shipping_details) ? $transaction->shipping_details : '', ['class' => 'form-control','placeholder' => __('sale.shipping_details'), 'required' ,'rows' => '4']); !!}
						</div>
					</div>

					<div class="col-md-6">
						<div class="form-group">
							{!! Form::label('shipping_address_modal', __('lang_v1.shipping_address') . ':' ) !!}
							{!! Form::textarea('shipping_address_modal',!empty($transaction->shipping_address) ? $transaction->shipping_address : '', ['class' => 'form-control','placeholder' => __('lang_v1.shipping_address') ,'rows' => '4']); !!}
						</div>
					</div>

					<div class="col-md-6">
						<div class="form-group">
							{!! Form::label('shipping_status_modal', __('lang_v1.shipping_status') . ':' ) !!}
							{!! Form::select('shipping_status_modal',$shipping_statuses, !empty($transaction->shipping_status) ? $transaction->shipping_status : null, ['class' => 'form-control','placeholder' => __('messages.please_select')]); !!}
						</div>
					</div>

					<div class="col-md-6">
						<div class="form-group">
							{!! Form::label('delivered_to_modal', __('lang_v1.delivered_to') . ':' ) !!}
							{!! Form::text('delivered_to_modal', !empty($transaction->delivered_to) ? $transaction->delivered_to : null, ['class' => 'form-control','placeholder' => __('lang_v1.delivered_to')]); !!}
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							{!! Form::label('delivery_person_modal', __('lang_v1.delivery_person') . ':' ) !!} <br>
							{!! Form::select('delivery_person_modal', $users, !empty($transaction->delivery_person) ? $transaction->delivery_person : null, ['style' => 'width:100%' ,'class' => 'form-control select2 width-100','placeholder' => __('messages.please_select')]); !!}
						</div>
					</div>
					@php
						$custom_labels = json_decode(session('business.custom_labels'), true);

                        $shipping_custom_label_1 = !empty($custom_labels['shipping']['custom_field_1']) ? $custom_labels['shipping']['custom_field_1'] : '';

                        $is_shipping_custom_field_1_required = !empty($custom_labels['shipping']['is_custom_field_1_required']) && $custom_labels['shipping']['is_custom_field_1_required'] == 1 ? true : false;

                        $shipping_custom_label_2 = !empty($custom_labels['shipping']['custom_field_2']) ? $custom_labels['shipping']['custom_field_2'] : '';

                        $is_shipping_custom_field_2_required = !empty($custom_labels['shipping']['is_custom_field_2_required']) && $custom_labels['shipping']['is_custom_field_2_required'] == 1 ? true : false;

                        $shipping_custom_label_3 = !empty($custom_labels['shipping']['custom_field_3']) ? $custom_labels['shipping']['custom_field_3'] : '';

                        $is_shipping_custom_field_3_required = !empty($custom_labels['shipping']['is_custom_field_3_required']) && $custom_labels['shipping']['is_custom_field_3_required'] == 1 ? true : false;

                        $shipping_custom_label_4 = !empty($custom_labels['shipping']['custom_field_4']) ? $custom_labels['shipping']['custom_field_4'] : '';

                        $is_shipping_custom_field_4_required = !empty($custom_labels['shipping']['is_custom_field_4_required']) && $custom_labels['shipping']['is_custom_field_4_required'] == 1 ? true : false;

                        $shipping_custom_label_5 = !empty($custom_labels['shipping']['custom_field_5']) ? $custom_labels['shipping']['custom_field_5'] : '';

                        $is_shipping_custom_field_5_required = !empty($custom_labels['shipping']['is_custom_field_5_required']) && $custom_labels['shipping']['is_custom_field_5_required'] == 1 ? true : false;
					@endphp

					@if(!empty($shipping_custom_label_1))
						@php
							$label_1 = $shipping_custom_label_1 . ':';
                            if($is_shipping_custom_field_1_required) {
                                $label_1 .= '*';
                            }
						@endphp

						<div class="col-md-6">
							<div class="form-group">
								{!! Form::label('shipping_custom_field_1', $label_1 ) !!}
								{!! Form::text('shipping_custom_field_1', !empty($transaction->shipping_custom_field_1) ? $transaction->shipping_custom_field_1 : null, ['class' => 'form-control','placeholder' => $shipping_custom_label_1, 'required' => $is_shipping_custom_field_1_required]); !!}
							</div>
						</div>
					@endif
					@if(!empty($shipping_custom_label_2))
						@php
							$label_2 = $shipping_custom_label_2 . ':';
                            if($is_shipping_custom_field_2_required) {
                                $label_2 .= '*';
                            }
						@endphp

						<div class="col-md-6">
							<div class="form-group">
								{!! Form::label('shipping_custom_field_2', $label_2 ) !!}
								{!! Form::text('shipping_custom_field_2', !empty($transaction->shipping_custom_field_2) ? $transaction->shipping_custom_field_2 : null, ['class' => 'form-control','placeholder' => $shipping_custom_label_2, 'required' => $is_shipping_custom_field_2_required]); !!}
							</div>
						</div>
					@endif
					@if(!empty($shipping_custom_label_3))
						@php
							$label_3 = $shipping_custom_label_3 . ':';
                            if($is_shipping_custom_field_3_required) {
                                $label_3 .= '*';
                            }
						@endphp

						<div class="col-md-6">
							<div class="form-group">
								{!! Form::label('shipping_custom_field_3', $label_3 ) !!}
								{!! Form::text('shipping_custom_field_3', !empty($transaction->shipping_custom_field_3) ? $transaction->shipping_custom_field_3 : null, ['class' => 'form-control','placeholder' => $shipping_custom_label_3, 'required' => $is_shipping_custom_field_3_required]); !!}
							</div>
						</div>
					@endif
					@if(!empty($shipping_custom_label_4))
						@php
							$label_4 = $shipping_custom_label_4 . ':';
                            if($is_shipping_custom_field_4_required) {
                                $label_4 .= '*';
                            }
						@endphp

						<div class="col-md-6">
							<div class="form-group">
								{!! Form::label('shipping_custom_field_4', $label_4 ) !!}
								{!! Form::text('shipping_custom_field_4', !empty($transaction->shipping_custom_field_4) ? $transaction->shipping_custom_field_4 : null, ['class' => 'form-control','placeholder' => $shipping_custom_label_4, 'required' => $is_shipping_custom_field_4_required]); !!}
							</div>
						</div>
					@endif
					@if(!empty($shipping_custom_label_5))
						@php
							$label_5 = $shipping_custom_label_5 . ':';
                            if($is_shipping_custom_field_5_required) {
                                $label_5 .= '*';
                            }
						@endphp

						<div class="col-md-6">
							<div class="form-group">
								{!! Form::label('shipping_custom_field_5', $label_5 ) !!}
								{!! Form::text('shipping_custom_field_5', !empty($transaction->shipping_custom_field_5) ? $transaction->shipping_custom_field_5 : null, ['class' => 'form-control','placeholder' => $shipping_custom_label_5, 'required' => $is_shipping_custom_field_5_required]); !!}
							</div>
						</div>
					@endif
				</div>
				<div id="aaa2" style="display: {{$is_show == 2 ? 'block' : 'none' }}" class="row">
					<div class="form-group col-md-6">
						{!! Form::label('reciver_phone', __('khairataladel::lang.reciver_phone') ) !!}
						{!! Form::text('reciver_phone',  json_decode($transaction->shipping_details,true) ['reciver_phone'] ?? '', ['class' => 'form-control', 'required', 'minlength' => 11 ]); !!}
					</div>
					<div class="form-group col-md-6">
						{!! Form::label('reciver_name', __( 'khairataladel::lang.reciver_name') ) !!}
						{!! Form::text('reciver_name',  json_decode($transaction->shipping_details,true) ['reciver_name'] ?? '', ['class' => 'form-control', 'required' ]); !!}
					</div>
					<div class="form-group col-md-12">
						{!! Form::label('el3nwan', __('khairataladel::lang.el3nwan') ) !!}
						{!! Form::text('el3nwan',  json_decode($transaction->shipping_details,true) ['el3nwan'] ?? '', ['class' => 'form-control', 'required'  ]); !!}
					</div>
					<?php
					$provinces = [
							"البصرة" => "البصرة",
							"ذي قار" => "ذي قار",
							"ميسان" => "ميسان",
							"المثنى" => "المثنى",
							"واسط" => "واسط",
							"بابل" => "بابل",
							"كربلاء" => "كربلاء",
							"النجف" => "النجف",
							"القادسية" => "القادسية",
							"بغداد" => "بغداد",
							"الانبار" => "الانبار",
							"صلاح الدين" => "صلاح الدين",
							"ديالى" => "ديالى",
							"نينوى" => "نينوى",
							"دهوك" => "دهوك",
							"كركوك" => "كركوك",
							"اربيل" => "اربيل",
							"السليمانية" => "السليمانية",
							"محافظة جديدة" => "محافظة جديدة"
					];
					?>
					<div class="form-group col-md-6">
						{!! Form::label('mo7afza', __('khairataladel::lang.mo7afza') ) !!}
						<select id="mo7afza" class="form-control" style="width: 100%;" required="" name="mo7afza">
							<option value="">----------------</option>
							@foreach($provinces as $key_ss=>$value_ss)
								<option value="{{$key_ss}}" {{ (json_decode($transaction->shipping_details,true) ['mo7afza'] ?? '-1') == $key_ss ? "selected" : "" }}>{{$value_ss}}</option>
							@endforeach
						</select>
					</div>
					<div class="form-group col-md-6">
						{!! Form::label('manteka', __('khairataladel::lang.manteka') ) !!}
						{!! Form::select('manteka', [(json_decode($transaction->shipping_details,true) ['manteka'] ?? '')], (json_decode($transaction->shipping_details,true) ['manteka'] ?? '') , ['id'=> 'manteka','class' => 'form-control','style' => 'width: 100%;', 'required']); !!}
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						{!! Form::label('shipping_charges_modal', __('sale.shipping_charges') . ':*' ) !!}
						<div class="input-group">
				                <span class="input-group-addon">
				                    <i class="fa fa-info"></i>
				                </span>
							{!! Form::text('shipping_charges_modal', !empty($transaction->shipping_charges) ? @num_format($transaction->shipping_charges) : 0, ['class' => 'form-control input_number input_number', 'data-decimal' => 'no_neg', 'placeholder' => __('sale.shipping_charges')]); !!}
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="tw-dw-btn tw-dw-btn-primary tw-text-white" id="posShippingModalUpdate">@lang('messages.update')</button>
			    <button type="button" class="tw-dw-btn tw-dw-btn-neutral tw-text-white" data-dismiss="modal">@lang('messages.cancel')</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
	window.onload = function() {
		$('input[type=radio][name="shipments_now"]').on('change', function() {
			if (this.value == '1') {
				$('#aaa1').show();
				$('#aaa2').hide();
			} else if (this.value == '2') {
				$('#aaa1').hide();
				$('#aaa2').show();
			}
		});
		@if(__('khairataladel::lang.khairataladel') != 'khairataladel::lang.khairataladel')

		$(document).on('change', '#mo7afza', function() {

			var cat = $(this).val();
			$.ajax({
				method: 'POST',
				url: '{{action('\Modules\Khairataladel\Http\Controllers\ShipmentsController@getCities')}}',
				dataType: 'html',
				data: { government: cat },
				success: function(result) {
					$('#manteka').html(result);

					<?php
							$seetings = (new \App\Utils\ModuleUtil)->getModuleData("Khairataladel_settings", []);
							?>

					if(cat == '{{$seetings['Khairataladel']['city']}}')
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['amount']}}');
					else
					if(cat == '{{$seetings['Khairataladel']['city1']}}')
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['amount1']}}');
					else
					if(cat == '{{$seetings['Khairataladel']['city2']}}')
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['amount2']}}');
					else
					if(cat == '{{$seetings['Khairataladel']['city3']}}')
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['amount3']}}');
					else
					if(cat == '{{$seetings['Khairataladel']['city4']}}')
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['amount4']}}');
					else
					if(cat == '{{$seetings['Khairataladel']['city5']}}')
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['amount5']}}');
					else
						$('#shipping_charges_modal').val('{{$seetings['Khairataladel']['remaining']}}');


					if( $('#mo7afza').val() == "")
					{
						alert('{{__('account.not_applicable')}}');
					}
					else
					{
						const jsonData = {
							ship_area: "الفرع الرئيسى",
							mo7afza: $('#mo7afza').val(),
							manteka: $('#manteka').val(),
							reciver_phone: $('#reciver_phone').val(),
							reciver_name: $('#reciver_name').val(),
							el3nwan: $('#el3nwan').val()
						};

						const jsonString = JSON.stringify(jsonData, null, 2);

						$('#shipping_details_modal').val(jsonString);
					}


				},
			});
		});

		@endif
	};

</script>
