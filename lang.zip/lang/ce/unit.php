<?php

 return [
     'units' => 'Einheiten',
     'manage_your_units' => 'Verwalte deine Einheiten',
     'all_your_units' => 'Alle deine Einheiten',
     'name' => 'Name',
     'short_name' => 'Kurzer Name',
     'allow_decimal' => 'Erlaube Dezimal',
     'added_success' => 'Einheit erfolgreich hinzugefügt',
     'updated_success' => 'Einheit erfolgreich aktualisiert',
     'deleted_success' => 'Einheit erfolgreich gelöscht',
     'add_unit' => 'Einheit hinzufügen',
     'edit_unit' => 'Bearbeitungseinheit',
 ];
