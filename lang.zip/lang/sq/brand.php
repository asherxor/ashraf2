<?php

 return [
     'brands' => 'Marka',
     'manage_your_brands' => 'Menaxho markat e tua',
     'all_your_brands' => 'Të gjitha markat tuaja',
     'note' => 'Shënim',
     'brand_name' => 'Emri i markës',
     'short_description' => 'Përshkrim i shkurtër',
     'added_success' => 'Marku u shtua me sukses',
     'updated_success' => 'Brand u përditësua me sukses',
     'deleted_success' => 'Brand fshihet me sukses',
     'add_brand' => 'Shto markë',
     'edit_brand' => 'Ndrysho markën',
 ];
